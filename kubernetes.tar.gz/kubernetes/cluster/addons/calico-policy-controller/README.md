# Calico Policy Controller
==============

Calico Policy Controller is an implementation of the Kubernetes network policy API.

Learn more at:
- https://github.com/projectcalico/k8s-policy
- http://kubernetes.io/docs/user-guide/networkpolicies/


[![Analytics](https://kubernetes-site.appspot.com/UA-36037335-10/GitHub/cluster/addons/calico-policy-controller/README.md?pixel)]()
